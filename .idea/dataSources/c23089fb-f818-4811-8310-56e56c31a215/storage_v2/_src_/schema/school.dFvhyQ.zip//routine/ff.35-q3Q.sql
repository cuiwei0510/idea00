create function ff(myid int) returns int
BEGIN
	declare mycount int;
	select count(*) into mycount from teacher where id>myid;
	RETURN mycount;
END;

