create procedure p1(IN myloginname varchar(20), IN myloginpwd varchar(20), IN myname varchar(20), IN mytel varchar(20))
BEGIN
	insert into teacher(loginname,loginpwd,name,tel) values(myloginname,myloginpwd,myname,mytel);
END;

