create procedure p2(IN myid int, OUT myname varchar(20))
BEGIN
	select name into myname from teacher where id=myid;
END;

